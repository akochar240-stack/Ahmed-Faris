import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import makeWASocket, { DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion } from '@whiskeysockets/baileys';
import P from 'pino';
import qrcode from 'qrcode-terminal';

const PORT = Number(process.env.PORT || 3001);
const GROUP_INVITE_LINK = process.env.GROUP_INVITE_LINK || 'https://chat.whatsapp.com/HZQxxPCb4iVHvElrh7VsGC?mode=gi_t';
const API_KEY = process.env.BOT_API_KEY || '';
let sock;
let connectionState = 'starting';
let lastQrAt = null;
let groupJid = process.env.GROUP_JID || '';

const app = express();
app.use(cors({ origin: true }));
app.use((req, res, next) => {
  if (req.headers['access-control-request-private-network'] === 'true') {
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
  }
  next();
});
app.use(express.json({ limit: '64kb' }));

function auth(req, res, next) {
  if (API_KEY && req.get('x-api-key') !== API_KEY) return res.status(401).json({ ok: false, error: 'Unauthorized' });
  next();
}

function getInviteCode() {
  try { return new URL(GROUP_INVITE_LINK).pathname.split('/').filter(Boolean).pop(); } catch { return ''; }
}

async function connectWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState('./auth_info_baileys');
  const { version } = await fetchLatestBaileysVersion();
  sock = makeWASocket({ version, auth: state, logger: P({ level: 'silent' }), printQRInTerminal: false, browser: ['Faris IT Bot', 'Chrome', '1.0.0'] });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    if (qr) { connectionState = 'qr_ready'; lastQrAt = new Date().toISOString(); console.log('\nScan this QR with WhatsApp > Linked devices:\n'); qrcode.generate(qr, { small: true }); }
    if (connection === 'open') { connectionState = 'connected'; console.log('WhatsApp connected.'); }
    if (connection === 'close') {
      connectionState = 'disconnected';
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log('WhatsApp disconnected.', shouldReconnect ? 'Reconnecting...' : 'Logged out; remove auth_info_baileys and restart.');
      if (shouldReconnect) setTimeout(connectWhatsApp, 3000);
    }
  });
}

async function resolveGroup() {
  if (!sock || connectionState !== 'connected') throw new Error('WhatsApp is not connected. Scan the QR first.');
  if (groupJid) return groupJid;
  const code = getInviteCode();
  if (!code) throw new Error('Invalid group invite link.');
  const metadata = await sock.groupGetInviteInfo(code);
  groupJid = metadata.id;
  console.log(`Group found: ${metadata.subject} (${groupJid})`);
  return groupJid;
}

app.get('/health', (_req, res) => res.json({ ok: true, connection: connectionState, lastQrAt, groupConfigured: Boolean(GROUP_INVITE_LINK) }));

app.post('/send-to-group', auth, async (req, res) => {
  try {
    const message = String(req.body?.message || '').trim();
    if (!message) return res.status(400).json({ ok: false, error: 'Message is required.' });
    const jid = await resolveGroup();
    await sock.sendMessage(jid, { text: message });
    res.json({ ok: true, groupJid: jid });
  } catch (error) {
    console.error(error);
    res.status(503).json({ ok: false, error: error instanceof Error ? error.message : 'Send failed.' });
  }
});

app.listen(PORT, () => console.log(`Faris IT WhatsApp bot API listening on http://localhost:${PORT}`));
connectWhatsApp().catch((error) => { connectionState = 'error'; console.error(error); });
